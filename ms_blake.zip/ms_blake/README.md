The folder `source` contains the pali texts as scraped from the 
mahasangiti website by Yuttadhammo. They have been modified only by
naming the files and arranging them by folder, the contents are
otherwise unchanged.
